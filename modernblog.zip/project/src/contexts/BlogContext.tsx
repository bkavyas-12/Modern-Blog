import React, { createContext, useContext, useState, ReactNode } from 'react';
import { BlogPost, Category, Tag } from '../types';
import { mockPosts, mockCategories, mockTags } from '../data/mockData';

interface BlogContextType {
  posts: BlogPost[];
  categories: Category[];
  tags: Tag[];
  searchQuery: string;
  selectedCategory: string | null;
  setSearchQuery: (query: string) => void;
  setSelectedCategory: (category: string | null) => void;
  getPostBySlug: (slug: string) => BlogPost | undefined;
  getFeaturedPosts: () => BlogPost[];
  getRecentPosts: (limit?: number) => BlogPost[];
  getPostsByCategory: (categorySlug: string) => BlogPost[];
  searchPosts: (query: string) => BlogPost[];
}

const BlogContext = createContext<BlogContextType | undefined>(undefined);

interface BlogProviderProps {
  children: ReactNode;
}

export const BlogProvider: React.FC<BlogProviderProps> = ({ children }) => {
  const [posts] = useState<BlogPost[]>(mockPosts);
  const [categories] = useState<Category[]>(mockCategories);
  const [tags] = useState<Tag[]>(mockTags);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const getPostBySlug = (slug: string): BlogPost | undefined => {
    return posts.find(post => post.slug === slug);
  };

  const getFeaturedPosts = (): BlogPost[] => {
    return posts
      .filter(post => post.status === 'published')
      .sort((a, b) => b.views - a.views)
      .slice(0, 3);
  };

  const getRecentPosts = (limit: number = 6): BlogPost[] => {
    return posts
      .filter(post => post.status === 'published')
      .sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime())
      .slice(0, limit);
  };

  const getPostsByCategory = (categorySlug: string): BlogPost[] => {
    return posts.filter(post => 
      post.status === 'published' && post.category.slug === categorySlug
    );
  };

  const searchPosts = (query: string): BlogPost[] => {
    if (!query) return posts.filter(post => post.status === 'published');
    
    const lowercaseQuery = query.toLowerCase();
    return posts.filter(post => 
      post.status === 'published' && (
        post.title.toLowerCase().includes(lowercaseQuery) ||
        post.content.toLowerCase().includes(lowercaseQuery) ||
        post.tags.some(tag => tag.name.toLowerCase().includes(lowercaseQuery))
      )
    );
  };

  const value: BlogContextType = {
    posts,
    categories,
    tags,
    searchQuery,
    selectedCategory,
    setSearchQuery,
    setSelectedCategory,
    getPostBySlug,
    getFeaturedPosts,
    getRecentPosts,
    getPostsByCategory,
    searchPosts
  };

  return (
    <BlogContext.Provider value={value}>
      {children}
    </BlogContext.Provider>
  );
};

export const useBlog = (): BlogContextType => {
  const context = useContext(BlogContext);
  if (context === undefined) {
    throw new Error('useBlog must be used within a BlogProvider');
  }
  return context;
};