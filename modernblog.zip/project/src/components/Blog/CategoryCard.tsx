import React from 'react';
import { Link } from 'react-router-dom';
import { Category } from '../../types';

interface CategoryCardProps {
  category: Category;
}

const CategoryCard: React.FC<CategoryCardProps> = ({ category }) => {
  return (
    <Link to={`/category/${category.slug}`}>
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1 group">
        <div 
          className="w-12 h-12 rounded-lg mb-4 flex items-center justify-center group-hover:scale-110 transition-transform duration-300"
          style={{ backgroundColor: category.color }}
        >
          <span className="text-white font-bold text-lg">
            {category.name.charAt(0)}
          </span>
        </div>
        
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
          {category.name}
        </h3>
        
        {category.description && (
          <p className="text-gray-600 dark:text-gray-300 text-sm mb-3">
            {category.description}
          </p>
        )}
        
        <div className="text-sm text-gray-500 dark:text-gray-400">
          {category.postCount} {category.postCount === 1 ? 'post' : 'posts'}
        </div>
      </div>
    </Link>
  );
};

export default CategoryCard;