import React from 'react';
import { Link } from 'react-router-dom';
import { format } from 'date-fns';
import { Clock, Eye, Heart, MessageCircle, User } from 'lucide-react';
import { BlogPost } from '../../types';

interface PostCardProps {
  post: BlogPost;
  featured?: boolean;
}

const PostCard: React.FC<PostCardProps> = ({ post, featured = false }) => {
  const cardClasses = featured
    ? "bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden group hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
    : "bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden group hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1";

  const imageClasses = featured
    ? "w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
    : "w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300";

  return (
    <article className={cardClasses}>
      <div className="relative overflow-hidden">
        <Link to={`/post/${post.slug}`}>
          <img
            src={post.featuredImage}
            alt={post.title}
            className={imageClasses}
          />
        </Link>
        <div className="absolute top-4 left-4">
          <span
            className="px-3 py-1 text-xs font-medium text-white rounded-full"
            style={{ backgroundColor: post.category.color }}
          >
            {post.category.name}
          </span>
        </div>
      </div>

      <div className={`p-${featured ? '6' : '4'}`}>
        <div className="flex items-center space-x-4 text-sm text-gray-500 dark:text-gray-400 mb-3">
          <div className="flex items-center space-x-1">
            {post.author.avatar ? (
              <img src={post.author.avatar} alt={post.author.username} className="w-5 h-5 rounded-full" />
            ) : (
              <User className="w-4 h-4" />
            )}
            <span>{post.author.username}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Clock className="w-4 h-4" />
            <span>{format(new Date(post.publishedAt), 'MMM dd, yyyy')}</span>
          </div>
        </div>

        <Link to={`/post/${post.slug}`}>
          <h2 className={`font-bold text-gray-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors mb-3 ${
            featured ? 'text-xl' : 'text-lg'
          }`}>
            {post.title}
          </h2>
        </Link>

        <p className="text-gray-600 dark:text-gray-300 mb-4 line-clamp-3">
          {post.excerpt}
        </p>

        {post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-4">
            {post.tags.slice(0, 3).map(tag => (
              <span
                key={tag.id}
                className="px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 rounded-full"
              >
                #{tag.name}
              </span>
            ))}
          </div>
        )}

        <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Eye className="w-4 h-4" />
              <span>{post.views}</span>
            </div>
            <div className="flex items-center space-x-1">
              <Heart className="w-4 h-4" />
              <span>{post.likes}</span>
            </div>
            <div className="flex items-center space-x-1">
              <MessageCircle className="w-4 h-4" />
              <span>{post.comments.length}</span>
            </div>
          </div>
          <Link
            to={`/post/${post.slug}`}
            className="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-medium"
          >
            Read More
          </Link>
        </div>
      </div>
    </article>
  );
};

export default PostCard;