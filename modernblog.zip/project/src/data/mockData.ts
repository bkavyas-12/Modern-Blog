import { BlogPost, Category, Tag, User, Comment } from '../types';

export const mockUsers: User[] = [
  {
    id: '1',
    username: 'johndoe',
    email: 'john@example.com',
    role: 'admin',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Tech enthusiast and full-stack developer with 10+ years of experience.',
    createdAt: new Date('2023-01-01')
  },
  {
    id: '2',
    username: 'sarahwilson',
    email: 'sarah@example.com',
    role: 'author',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'UX designer passionate about creating intuitive digital experiences.',
    createdAt: new Date('2023-02-15')
  },
  {
    id: '3',
    username: 'mikejohnson',
    email: 'mike@example.com',
    role: 'author',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150',
    bio: 'Data scientist exploring the intersection of AI and web development.',
    createdAt: new Date('2023-03-10')
  }
];

export const mockCategories: Category[] = [
  {
    id: '1',
    name: 'Technology',
    slug: 'technology',
    description: 'Latest trends in technology and development',
    color: '#3b82f6',
    postCount: 12
  },
  {
    id: '2',
    name: 'Design',
    slug: 'design',
    description: 'UI/UX design tips and inspiration',
    color: '#8b5cf6',
    postCount: 8
  },
  {
    id: '3',
    name: 'Business',
    slug: 'business',
    description: 'Entrepreneurship and business insights',
    color: '#10b981',
    postCount: 6
  },
  {
    id: '4',
    name: 'Lifestyle',
    slug: 'lifestyle',
    description: 'Work-life balance and productivity',
    color: '#f59e0b',
    postCount: 4
  }
];

export const mockTags: Tag[] = [
  { id: '1', name: 'React', slug: 'react', color: '#61dafb' },
  { id: '2', name: 'JavaScript', slug: 'javascript', color: '#f7df1e' },
  { id: '3', name: 'TypeScript', slug: 'typescript', color: '#3178c6' },
  { id: '4', name: 'Node.js', slug: 'nodejs', color: '#339933' },
  { id: '5', name: 'CSS', slug: 'css', color: '#1572b6' },
  { id: '6', name: 'UI/UX', slug: 'uiux', color: '#ff6b6b' },
  { id: '7', name: 'AI', slug: 'ai', color: '#9c27b0' },
  { id: '8', name: 'Machine Learning', slug: 'ml', color: '#ff9800' }
];

export const mockComments: Comment[] = [
  {
    id: '1',
    content: 'Great article! Really helpful insights on modern React patterns.',
    author: mockUsers[1],
    postId: '1',
    createdAt: new Date('2024-01-15'),
    likes: 5,
    status: 'approved'
  },
  {
    id: '2',
    content: 'Thanks for sharing this. The code examples are really clear.',
    author: mockUsers[2],
    postId: '1',
    createdAt: new Date('2024-01-16'),
    likes: 3,
    status: 'approved'
  }
];

export const mockPosts: BlogPost[] = [
  {
    id: '1',
    title: 'Building Modern React Applications with TypeScript',
    content: `
      <h2>Introduction</h2>
      <p>React and TypeScript have become an incredibly powerful combination for building modern web applications. In this comprehensive guide, we'll explore how to leverage TypeScript's type safety with React's component-based architecture.</p>
      
      <h2>Setting Up Your Development Environment</h2>
      <p>Before we dive into the code, let's ensure you have the right tools configured for an optimal development experience.</p>
      
      <h2>Type-Safe Components</h2>
      <p>One of the biggest advantages of using TypeScript with React is the ability to create type-safe components that catch errors at compile time rather than runtime.</p>
      
      <h2>Advanced Patterns</h2>
      <p>We'll explore advanced patterns like generic components, higher-order components with proper typing, and custom hooks with TypeScript.</p>
    `,
    excerpt: 'Learn how to build robust, type-safe React applications using TypeScript. This comprehensive guide covers setup, best practices, and advanced patterns.',
    slug: 'building-modern-react-applications-typescript',
    author: mockUsers[0],
    category: mockCategories[0],
    tags: [mockTags[0], mockTags[2]],
    featuredImage: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date('2024-01-10'),
    updatedAt: new Date('2024-01-10'),
    views: 1250,
    likes: 89,
    status: 'published',
    comments: mockComments.filter(c => c.postId === '1')
  },
  {
    id: '2',
    title: 'The Future of Web Design: Trends to Watch in 2024',
    content: `
      <h2>Design Evolution</h2>
      <p>Web design continues to evolve at a rapid pace, with new trends emerging that push the boundaries of user experience and visual storytelling.</p>
      
      <h2>Minimalism with Purpose</h2>
      <p>The trend toward minimalism isn't just about removing elements—it's about creating purposeful, intentional designs that guide users toward their goals.</p>
      
      <h2>Interactive Experiences</h2>
      <p>Modern web applications are becoming more interactive, with micro-animations and immersive experiences that engage users on a deeper level.</p>
    `,
    excerpt: 'Explore the cutting-edge design trends that are shaping the future of web development and user experience in 2024.',
    slug: 'future-web-design-trends-2024',
    author: mockUsers[1],
    category: mockCategories[1],
    tags: [mockTags[5], mockTags[4]],
    featuredImage: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date('2024-01-08'),
    updatedAt: new Date('2024-01-08'),
    views: 980,
    likes: 67,
    status: 'published',
    comments: []
  },
  {
    id: '3',
    title: 'Machine Learning in Web Development: A Practical Guide',
    content: `
      <h2>AI-Powered Web Applications</h2>
      <p>The integration of machine learning into web development is no longer a futuristic concept—it's happening right now, and the possibilities are endless.</p>
      
      <h2>Getting Started with TensorFlow.js</h2>
      <p>TensorFlow.js brings machine learning directly to the browser, enabling developers to create intelligent web applications without server-side processing.</p>
      
      <h2>Real-World Applications</h2>
      <p>From image recognition to natural language processing, we'll explore practical applications of ML in web development.</p>
    `,
    excerpt: 'Discover how to integrate machine learning into your web applications using modern JavaScript frameworks and tools.',
    slug: 'machine-learning-web-development-guide',
    author: mockUsers[2],
    category: mockCategories[0],
    tags: [mockTags[6], mockTags[7], mockTags[1]],
    featuredImage: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date('2024-01-05'),
    updatedAt: new Date('2024-01-05'),
    views: 1450,
    likes: 124,
    status: 'published',
    comments: []
  },
  {
    id: '4',
    title: 'Building Scalable Node.js Applications',
    content: `
      <h2>Architecture Patterns</h2>
      <p>Building scalable Node.js applications requires thoughtful architecture decisions from the very beginning of your project.</p>
      
      <h2>Performance Optimization</h2>
      <p>Learn how to optimize your Node.js applications for maximum performance and scalability.</p>
      
      <h2>Deployment Strategies</h2>
      <p>Explore different deployment strategies and best practices for production environments.</p>
    `,
    excerpt: 'Learn essential patterns and practices for building Node.js applications that can scale to handle millions of users.',
    slug: 'building-scalable-nodejs-applications',
    author: mockUsers[0],
    category: mockCategories[0],
    tags: [mockTags[3], mockTags[1]],
    featuredImage: 'https://images.pexels.com/photos/1181263/pexels-photo-1181263.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date('2024-01-03'),
    updatedAt: new Date('2024-01-03'),
    views: 890,
    likes: 56,
    status: 'published',
    comments: []
  },
  {
    id: '5',
    title: 'Entrepreneurship in the Digital Age',
    content: `
      <h2>The Digital Revolution</h2>
      <p>The digital transformation has created unprecedented opportunities for entrepreneurs to build and scale businesses globally.</p>
      
      <h2>Building Your MVP</h2>
      <p>Learn how to quickly validate your ideas and build minimum viable products that resonate with your target audience.</p>
      
      <h2>Growth Strategies</h2>
      <p>Discover proven strategies for scaling your digital business and building sustainable growth.</p>
    `,
    excerpt: 'Navigate the challenges and opportunities of building a successful business in today\'s digital landscape.',
    slug: 'entrepreneurship-digital-age',
    author: mockUsers[1],
    category: mockCategories[2],
    tags: [],
    featuredImage: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date('2024-01-01'),
    updatedAt: new Date('2024-01-01'),
    views: 720,
    likes: 45,
    status: 'published',
    comments: []
  },
  {
    id: '6',
    title: 'Work-Life Balance for Developers',
    content: `
      <h2>Finding Balance</h2>
      <p>As developers, we often get caught up in the excitement of coding and forget to maintain a healthy work-life balance.</p>
      
      <h2>Productivity Tips</h2>
      <p>Learn effective strategies for managing your time and staying productive while maintaining your well-being.</p>
      
      <h2>Mental Health</h2>
      <p>The importance of mental health in the tech industry and practical tips for maintaining psychological well-being.</p>
    `,
    excerpt: 'Essential strategies for maintaining a healthy work-life balance while building a successful career in tech.',
    slug: 'work-life-balance-developers',
    author: mockUsers[2],
    category: mockCategories[3],
    tags: [],
    featuredImage: 'https://images.pexels.com/photos/1181534/pexels-photo-1181534.jpeg?auto=compress&cs=tinysrgb&w=800',
    publishedAt: new Date('2023-12-28'),
    updatedAt: new Date('2023-12-28'),
    views: 650,
    likes: 38,
    status: 'published',
    comments: []
  }
];