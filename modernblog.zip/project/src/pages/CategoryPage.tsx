import React from 'react';
import { useParams } from 'react-router-dom';
import PostCard from '../components/Blog/PostCard';
import { useBlog } from '../contexts/BlogContext';

const CategoryPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const { categories, getPostsByCategory } = useBlog();
  
  const category = categories.find(cat => cat.slug === slug);
  const posts = slug ? getPostsByCategory(slug) : [];

  if (!category) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Category Not Found
          </h1>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div 
            className="w-16 h-16 rounded-lg mx-auto mb-4 flex items-center justify-center"
            style={{ backgroundColor: category.color }}
          >
            <span className="text-white font-bold text-2xl">
              {category.name.charAt(0)}
            </span>
          </div>
          
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            {category.name}
          </h1>
          
          {category.description && (
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto mb-4">
              {category.description}
            </p>
          )}
          
          <p className="text-gray-500 dark:text-gray-400">
            {category.postCount} {category.postCount === 1 ? 'article' : 'articles'}
          </p>
        </div>

        {/* Posts Grid */}
        {posts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {posts.map(post => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-500 dark:text-gray-400 text-lg">
              No articles found in this category yet.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CategoryPage;