import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search } from 'lucide-react';
import PostCard from '../components/Blog/PostCard';
import { useBlog } from '../contexts/BlogContext';
import { BlogPost } from '../types';

const SearchPage: React.FC = () => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [searchResults, setSearchResults] = useState<BlogPost[]>([]);
  const { searchPosts } = useBlog();

  useEffect(() => {
    if (query) {
      const results = searchPosts(query);
      setSearchResults(results);
    }
  }, [query, searchPosts]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Search className="w-12 h-12 text-blue-600 dark:text-blue-400" />
          </div>
          
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Search Results
          </h1>
          
          {query && (
            <p className="text-xl text-gray-600 dark:text-gray-400">
              Results for: <span className="font-semibold">"{query}"</span>
            </p>
          )}
          
          <p className="text-gray-500 dark:text-gray-400 mt-2">
            {searchResults.length} {searchResults.length === 1 ? 'article' : 'articles'} found
          </p>
        </div>

        {/* Search Results */}
        {searchResults.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {searchResults.map(post => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        ) : query ? (
          <div className="text-center py-12">
            <p className="text-gray-500 dark:text-gray-400 text-lg mb-4">
              No articles found for your search query.
            </p>
            <p className="text-gray-400 dark:text-gray-500">
              Try different keywords or browse our categories.
            </p>
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-gray-500 dark:text-gray-400 text-lg">
              Enter a search query to find articles.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchPage;