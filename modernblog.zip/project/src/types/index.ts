export interface User {
  id: string;
  username: string;
  email: string;
  role: 'reader' | 'author' | 'admin';
  avatar?: string;
  bio?: string;
  createdAt: Date;
}

export interface BlogPost {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  slug: string;
  author: User;
  category: Category;
  tags: Tag[];
  featuredImage?: string;
  publishedAt: Date;
  updatedAt: Date;
  views: number;
  likes: number;
  status: 'draft' | 'published';
  comments: Comment[];
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  color: string;
  postCount: number;
}

export interface Tag {
  id: string;
  name: string;
  slug: string;
  color: string;
}

export interface Comment {
  id: string;
  content: string;
  author: User;
  postId: string;
  parentId?: string;
  createdAt: Date;
  likes: number;
  status: 'approved' | 'pending' | 'rejected';
  replies?: Comment[];
}

export interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
  register: (userData: RegisterData) => Promise<void>;
  isLoading: boolean;
}

export interface RegisterData {
  username: string;
  email: string;
  password: string;
  role?: 'reader' | 'author';
}

export interface ThemeContextType {
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}